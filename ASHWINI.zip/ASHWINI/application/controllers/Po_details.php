<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Po_details extends CI_Controller {

	function __construct() {
		parent::__construct();
        $this->load->helper('url','form','form_validation');
        $this->load->model('Po_details_model');
        $this->load->library('session');
        $this->load->database();
    }

	public function index()
	{
		$this->load->view('details/header');
		$this->load->view('details/view_details');
		$this->load->view('details/footer');
		
	}

	public function add_details()
	{
		if(isset($_POST) && !empty($_POST)){
			$product_details = array();
			$count = count($_POST['product_name']);
			for($i=0;$i<$count;$i++){
				$product_details1['product_name'] = $_POST['product_name'][$i];
				$product_details1['qty'] = $_POST['qty'][$i];
				$product_details1['rate'] = $_POST['rate'][$i];
				$product_details1['tax'] = $_POST['tax'][$i];
				$product_details1['amt'] = $_POST['amt'][$i];
				$product_details[] = $product_details1;
			}

			$data = array(
				'po_no' => $this->input->post('Po_num'),
				'company_name' => $this->input->post('com_name'),
				'address' => $this->input->post('Address'),
				'mobile' => $this->input->post('mobile'),
				'po_date' => $this->input->post('po_date'),
				'sub' => $this->input->post('sub_total'),
				'total' => $this->input->post('total'),
				'round_off' => $this->input->post('round_off'),
				'grand_total' => $this->input->post('grand_total'),
				'product_details' => json_encode($product_details),
				'created_date' => date('Y-m-d H:i:s')
			);
			$this->Po_details_model->insert_data($data);
			$this->session->set_flashdata('msg','<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>                    
                    <i class="icon fa fa-check"></i>Product Details Added Successfully.
                  </div>
				  ');			
				 redirect(base_url().'Po_details'); 	
		}else{
			$this->load->view('details/header');
			$this->load->view('details/add_details');
			$this->load->view('details/footer');
		}
	}

	public function edit_details()
	{
		
		if(isset($_POST) && !empty($_POST)){
			$id = $this->input->post('id');
			$product_details = array();
			$count = count($_POST['product_name']);
			for($i=0;$i<$count;$i++){
				$product_details1['product_name'] = $_POST['product_name'][$i];
				$product_details1['qty'] = $_POST['qty'][$i];
				$product_details1['rate'] = $_POST['rate'][$i];
				$product_details1['tax'] = $_POST['tax'][$i];
				$product_details1['amt'] = $_POST['amt'][$i];
				$product_details[] = $product_details1;
			}

			$data = array(
				'po_no' => $this->input->post('Po_num'),
				'company_name' => $this->input->post('com_name'),
				'address' => $this->input->post('Address'),
				'mobile' => $this->input->post('mobile'),
				'po_date' => $this->input->post('po_date'),
				'sub' => $this->input->post('sub_total'),
				'total' => $this->input->post('total'),
				'round_off' => $this->input->post('round_off'),
				'grand_total' => $this->input->post('grand_total'),
				'product_details' => json_encode($product_details),
			);
			$this->Po_details_model->update_data($data,$id);
			$this->session->set_flashdata('msg','<div class="alert alert-success alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>                    
                    <i class="icon fa fa-check"></i>Product Details Updated Successfully.
                  </div>
				  ');			
				 redirect(base_url().'Po_details'); 	
		}else{
			//$id = $this->uri->segment(3);
			$id = 3;
			$product_details = $this->Po_details_model->get_data_by_id($id);
			$data['product_details'] = $product_details[0];
			$this->load->view('details/header');
			$this->load->view('details/edit_details',$data);
			$this->load->view('details/footer');
		}
	}

	public function get_cmp_name(){
		$keyword    = $this->uri->segment(3);
        $keyword1   = ucfirst ($keyword);
        $data = [];
        $d = $this->Po_details_model->get_cmp_name($keyword1);
            foreach($d as $ckey => $cvalue){
                if (strpos(strtolower($cvalue['c_name']), strtolower($keyword)) !== FALSE){
                    $data[] = $cvalue;
                }
            } 
        foreach ($data as $val => $key)
        {
            $c_name        = strtolower($key['c_name']);
            $name_code[]   =  ucwords($c_name);
        }   
        echo json_encode($name_code);
	}
}

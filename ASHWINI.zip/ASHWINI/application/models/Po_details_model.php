<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Po_details_model extends CI_Model {

	function __construct() {
        parent::__construct();
    }

	public function get_cmp_name()
	{
		$this->db->select('*');      
        $result = $this->db->get('tbl_company_names')->result_array();
        return $result;
	}

	public function insert_data($data){
		$this->db->insert('tbl_order_details', $data);
		return;
	}

	public function update_data($id,$data){
		$this->db->where('id',$id);
		$this->db->update('tbl_order_details', $data);
		return;
	}

	public function get_data_by_id($id){
		$this->db->select('*');
		$this->db->from('tbl_order_details');
		$this->db->where('id',$id);
		$result = $this->db->get()->result_array();
        return $result;
	}
}

<div class="container mt-5 mb-2">
  <div class="row">
    <div class="col-sm-10">
      <h4 class="font-weight-bold">Add Details</h4>
    </div>
    <div class="col-sm-2">
      <button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger form-control"><i class="fa fa-arrow-left"></i>&nbsp;Back</button>
    </div>
  </div>
</div>
<div class="container p-3">
  <form name="create_data" id="create_data" method="post" action="add_details" enctype="multipart/form-data">
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Po no.:</lable>
              </div>
              <div class="col-sm-8">
                 <input class="form-control" type="text" name="Po_num" value="<?php echo 'PO'.date('ymdhis'); ?>" readonly>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Company Name:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control com_name" name="com_name" id="com_name" autocomplete="off" required>
              </div>
      </div>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Address:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="Address" required>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Mobile No:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="mobile" required>
              </div>
           </div>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Po Date:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="date" class="form-control" name="po_date" required>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      
    </div>
  </div>
  <div class="row mt-2">
  	<table class="table table-bordered table-striped table-hover" id="pass_table" style="width:100%">
         <thead>
            <tr>
                <th>Sl. No</th>
                <th>Product Name</th>
                <th>Avail Qty</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Tax</th>
                <th>amount</th>
                <th>Action</th>
            </tr>
         </thead>
         <tbody>
        <tr>
        <td>1</td>
        <td><input type="text" name="product_name[]"></td>
        <td>3</td>
        <td><input type="text" name="qty[]" id="qty1"></td>
        <td><input type="text" name="rate[]" id="rate1"></td>
        <td><select class="tax_select" row-id="1" name="tax[]" id="tax1"><option value="1">Select Tax</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option></select></td>
        <td><input type="text" name="amt[]" id="amt1" value="" readonly></td>
        <td><?php
                  echo '<p><i class="fa fa-trash fa-fw fa-lg" style="color:#b80303;"></i></p>';
                  ?>
        </td>
      </tr> 
         </tbody>
         
      </table>
      
      
  </div>
  <div class="row mt-2">
    		<div class="col-sm-2">
    			<button type="button" class="btn btn-danger form-control" id="bfCaptchaEntry" onclick="javascript:addfield();"><i class="fa fa-add"></i>&nbsp;Add</button>
    		</div>
    		<div class="col-sm-10">
    		</div>
 </div>

 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Sub Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="sub_total" id="sub_total" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="total" id="total" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Round Off:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="round_off" id="round_off" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Grand Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="grand_total" id="grand_total" readonly>
              </div>
           </div>
    		</div>
 </div>

  <div class="row mt-3">
    <div class="col-sm-2">
    </div>
    <div class="offset-2 col-sm-2">
      <button type="submit" class="btn btn-danger form-control submit_btn" id="bfCaptchaEntry"><i class="fa fa-save"></i>&nbsp;Save Details</button>
    </div>
    <div class="col-sm-2">
      <button type="reset" class="btn btn-danger form-control"><i class="fa fa-refresh fa-fw"></i>&nbsp;Reset</button>
    </div>
  </div>
  </form>
  <input type="hidden" id="base_url" value="<?php echo base_url(); ?>" >
  <input type="hidden" id="csrf_name" value="<?php echo $this->security->get_csrf_token_name(); ?>">
<input type="hidden" id="csrf_value" name = "<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
</div>

<script type="text/javascript">
 var j = 2;
   function addfield(){
		row = $('<tr id="row'+j+'"> <td>'+j+'</td><td><input type="text" name="product_name[]"></td><td>3</td><td><input type="text" name="qty[]" id="qty'+j+'"></td><td><input type="text" name="rate[]" id="rate'+j+'"></td><td><select class="tax_select" row-id="'+j+'" name="tax[]"><option value="1">Select Tax</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option></select></td><td><input type="text" readonly name="amt[]" id="amt'+j+'"></td><td><p><i class="fa fa-trash fa-fw fa-lg removeRow" data-id="'+j+'" style="color:#b80303;"></i></p> </td></tr>');
		  $('#pass_table tr:last').after(row);
		  j++;
}
$(document).ready(function(){
	$(document).on('click', '.removeRow', function (event) {
    var id = $(this).attr('data-id');
    j--;
    $("#row"+j).closest("tr").remove();
    });

	$(document).on('change', '.tax_select', function (event) {
		var tax = $('.tax_select option:selected').val();
		var row = $(this).attr('row-id');
		var qty = $('#qty'+row).val();
		var rate = $('#rate'+row).val();
		var total_tax = (parseFloat(qty)*parseFloat(rate))*(parseFloat(tax)/100);
		var total = (parseFloat(qty)*parseFloat(rate)) + total_tax;
		$('#amt'+row).val(total);
		var sub = 0;
		var total1 = 0;
		var round_off = 0;
		var grand_total = 0;
		 for (var i = 1; i < j; i++) {
		 	total1 = parseFloat(total1) + parseFloat($('#amt'+i).val());
		 	sub = parseFloat(sub) + (parseFloat($('#qty'+i).val()) * parseFloat($('#rate'+i).val()));
		 	
		 }
		 round_off = parseFloat(Math.round(total1));
		 grand_total = parseFloat(Math.round(round_off));

		 $('#sub_total').val(sub);
		 $('#total').val(total1);
		 $('#round_off').val(round_off);
		 $('#grand_total').val(grand_total);
	});

	$(function(){
	var csrf_name = $('#csrf_value').val();		
		$("#com_name").autocomplete({
			source:function(request,response){
			$.ajax({
				data : {'csrf_test_name':csrf_name },
				url:$("#base_url").val()+"Po_details/get_cmp_name/"+$("#com_name").val(),
				success:function(data){
					alert("data"+data)
					response($.map(data,function(value,key){
						var obj=value.trim();
						return{label:value}}))},dataType:'json'})},
					select:function(event,ui){
						var cName=ui.item.label;
						$("#com_name").val(cName);
						return!1},minLength:1})
	});
});
</script>
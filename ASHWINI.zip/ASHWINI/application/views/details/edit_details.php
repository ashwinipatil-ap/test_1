<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//echo "<pre>"; print_r($product_details); die;
?>
<div class="container mt-5 mb-2">
  <div class="row">
    <div class="col-sm-10">
      <h4 class="font-weight-bold">Update Details</h4>
    </div>
    <div class="col-sm-2">
      <button type="button" onclick="javascript:window.history.back(-1);" class="btn btn-danger form-control"><i class="fa fa-arrow-left"></i>&nbsp;Back</button>
    </div>
  </div>
</div>
<div class="container p-3">
  <form name="edit_details" id="edit_details" method="post" action="edit_details" enctype="multipart/form-data">
  	<input type="hidden" class="form-control" name="id" value="<?php echo $product_details['id']; ?>" required>
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Po no.:</lable>
              </div>
              <div class="col-sm-8">
                 <input class="form-control" type="text" name="Po_num" value="<?php echo $product_details['po_no']; ?>" readonly>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Company Name:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control com_name" name="com_name" id="com_name" value="<?php echo $product_details['company_name']; ?>" autocomplete="off" required>
              </div>
      </div>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Address:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="Address" value="<?php echo $product_details['address']; ?>" required>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Mobile No:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="mobile" value="<?php echo $product_details['mobile']; ?>" required>
              </div>
           </div>
    </div>
  </div>
  <div class="row mt-2">
    <div class="col-sm-6">
      <div class="row">
              <div class="col-sm-4">
                 <lable>Po Date:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="date" class="form-control" name="po_date" value="<?php echo $product_details['po_date']; ?>" required>
              </div>
           </div>
    </div>
    <div class="col-sm-6">
      
    </div>
  </div>
  <div class="row mt-2">
  	<table class="table table-bordered table-striped table-hover" id="pass_table" style="width:100%">
         <thead>
            <tr>
                <th>Sl. No</th>
                <th>Product Name</th>
                <th>Avail Qty</th>
                <th>Qty</th>
                <th>Rate</th>
                <th>Tax</th>
                <th>amount</th>
                <th>Action</th>
            </tr>
         </thead>
         <tbody>
         	<?php 
         		$product_details1 = json_decode($product_details['product_details'],true);
         		$count = count($product_details1);
         		foreach ($product_details1 as $key => $value) { 
         			$row_id = $key+1;
         			$row_id = 'row'.$row_id;
         			?>
         			<tr id="<?php echo $row_id; ?>">
				        <td><?php echo $key+1; ?></td>
				        <td><input type="text" name="product_name[]" value="<?php echo $value['product_name']; ?>"></td>
				        <td>3</td>
				        <td><input type="text" name="qty[]" id="qty1" value="<?php echo $value['qty']; ?>"></td>
				        <td><input type="text" name="rate[]" id="rate1" value="<?php echo $value['rate']; ?>"></td>
				        <td><select class="tax_select" row-id="1" name="tax[]" id="tax1">
				        	<?php if($value['tax'] == 5){ ?>
				        		<option value="5" selected>5%</option>
				        	    <option value="12">12%</option>
				        	    <option value="18">18%</option>
				        	<?php }else if($value['tax'] == 12){ ?>
				        		<option value="5">5%</option>
				        	    <option value="12" selected>12%</option>
				        	    <option value="18">18%</option>
				        	<?php }else{ ?>
				        		<option value="5">5%</option>
				        	    <option value="12">12%</option>
				        	    <option value="18" selected>18%</option>
				        	<?php } ?>
				        </select></td>
				        <td><input type="text" name="amt[]" id="amt1" value="<?php echo $value['amt']; ?>" readonly></td>
				        <td>
				                  <p><i class="fa fa-trash fa-fw fa-lg removeRow" data-id="<?php echo $key+1; ?>" style="color:#b80303;"></i></p>
				        </td>
				      </tr>
			<?php } ?>
         
         </tbody>
         
      </table>
      
      
  </div>
  <div class="row mt-2">
    		<div class="col-sm-2">
    			<button type="button" class="btn btn-danger form-control" id="bfCaptchaEntry" onclick="javascript:addfield();"><i class="fa fa-add"></i>&nbsp;Add</button>
    		</div>
    		<div class="col-sm-10">
    		</div>
 </div>

 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Sub Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="sub_total" id="sub_total" value="<?php echo $product_details['sub']; ?>" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="total" id="total" value="<?php echo $product_details['total']; ?>" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Round Off:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="round_off" id="round_off" value="<?php echo $product_details['round_off']; ?>" readonly>
              </div>
           </div>
    		</div>
 </div>
 <div class="row mt-2">
    		<div class="col-sm-8">
    		</div>
    		<div class="col-sm-4">
    		<div class="row">
              <div class="col-sm-4">
                 <lable>Grand Total:</lable>
              </div>
              <div class="col-sm-8">
                 <input type="text" class="form-control" name="grand_total" id="grand_total" value="<?php echo $product_details['grand_total']; ?>" readonly>
              </div>
           </div>
    		</div>
 </div>

  <div class="row mt-3">
    <div class="col-sm-2">
    </div>
    <div class="offset-2 col-sm-2">
      <button type="submit" class="btn btn-danger form-control submit_btn" id="bfCaptchaEntry"><i class="fa fa-save"></i>&nbsp;Update Details</button>
    </div>
    <div class="col-sm-2">
      <button type="reset" class="btn btn-danger form-control"><i class="fa fa-refresh fa-fw"></i>&nbsp;Reset</button>
    </div>
  </div>
  </form>
  <input type="hidden" id="base_url" value="<?php echo base_url(); ?>" >
  <input type="hidden" id="count" value="<?php echo $count; ?>" >
  <input type="hidden" id="csrf_name" value="<?php echo $this->security->get_csrf_token_name(); ?>">
<input type="hidden" id="csrf_value" name = "<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
</div>

<script type="text/javascript">
   var j = 0;
   function addfield(){
		row = $('<tr id="row'+j+'"> <td>'+j+'</td><td><input type="text" name="product_name[]"></td><td>3</td><td><input type="text" name="qty[]" id="qty'+j+'"></td><td><input type="text" name="rate[]" id="rate'+j+'"></td><td><select class="tax_select" row-id="'+j+'" name="tax[]"><option value="1">Select Tax</option><option value="5">5%</option><option value="12">12%</option><option value="18">18%</option></select></td><td><input type="text" readonly name="amt[]" id="amt'+j+'"></td><td><p><i class="fa fa-trash fa-fw fa-lg removeRow" data-id="'+j+'" style="color:#b80303;"></i></p> </td></tr>');
		  $('#pass_table tr:last').after(row);
		  j++;
}
$(document).ready(function(){
	j = $('#count').val();
	j++;
	$(document).on('click', '.removeRow', function (event) {
    var id = $(this).attr('data-id');
    j--;
    $("#row"+j).closest("tr").remove();

    var tax = $('.tax_select option:selected').val();
		var row = $(this).attr('row-id');
		var qty = $('#qty'+row).val();
		var rate = $('#rate'+row).val();
		var total_tax = (parseFloat(qty)*parseFloat(rate))*(parseFloat(tax)/100);
		var total = (parseFloat(qty)*parseFloat(rate)) + total_tax;
		$('#amt'+row).val(total);
		var sub = 0;
		var total1 = 0;
		var round_off = 0;
		var grand_total = 0;
		 for (var i = 1; i < j; i++) {
		 	total1 = parseFloat(total1) + parseFloat($('#amt'+i).val());
		 	sub = parseFloat(sub) + (parseFloat($('#qty'+i).val()) * parseFloat($('#rate'+i).val()));
		 	
		 }
		 round_off = parseFloat(Math.round(total1));
		 grand_total = parseFloat(Math.round(round_off));

		 $('#sub_total').val(sub);
		 $('#total').val(total1);
		 $('#round_off').val(round_off);
		 $('#grand_total').val(grand_total);
    });

	$(document).on('change', '.tax_select', function (event) {
		var tax = $('.tax_select option:selected').val();
		var row = $(this).attr('row-id');
		var qty = $('#qty'+row).val();
		var rate = $('#rate'+row).val();
		var total_tax = (parseFloat(qty)*parseFloat(rate))*(parseFloat(tax)/100);
		var total = (parseFloat(qty)*parseFloat(rate)) + total_tax;
		$('#amt'+row).val(total);
		var sub = 0;
		var total1 = 0;
		var round_off = 0;
		var grand_total = 0;
		 for (var i = 1; i < j; i++) {
		 	total1 = parseFloat(total1) + parseFloat($('#amt'+i).val());
		 	sub = parseFloat(sub) + (parseFloat($('#qty'+i).val()) * parseFloat($('#rate'+i).val()));
		 	
		 }
		 round_off = parseFloat(Math.round(total1));
		 grand_total = parseFloat(Math.round(round_off));

		 $('#sub_total').val(sub);
		 $('#total').val(total1);
		 $('#round_off').val(round_off);
		 $('#grand_total').val(grand_total);
	});

	$(function(){
	var csrf_name = $('#csrf_value').val();		
		$("#com_name").autocomplete({
			source:function(request,response){
			$.ajax({
				data : {'csrf_test_name':csrf_name },
				url:$("#base_url").val()+"Po_details/get_cmp_name/"+$("#com_name").val(),
				success:function(data){
					alert("data"+data)
					response($.map(data,function(value,key){
						var obj=value.trim();
						return{label:value}}))},dataType:'json'})},
					select:function(event,ui){
						var cName=ui.item.label;
						$("#com_name").val(cName);
						return!1},minLength:1})
	});
});
</script>